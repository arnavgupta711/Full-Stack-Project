if (document.querySelector(".dangerMessage").innerHTML === `true`){
    $(".dangerMessage").css("display", "none");
}